'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-sky-100">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-sky-500 rounded-full flex items-center justify-center">
              <i className="ri-hospital-line text-white text-xl"></i>
            </div>
            <span className="text-2xl font-bold text-sky-600" style={{fontFamily: "Pacifico, serif"}}>
              MediCare
            </span>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-sky-600 transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/doctors" className="text-gray-700 hover:text-sky-600 transition-colors cursor-pointer">
              Doctors
            </Link>
            <Link href="/services" className="text-gray-700 hover:text-sky-600 transition-colors cursor-pointer">
              Services
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-sky-600 transition-colors cursor-pointer">
              About
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-sky-600 transition-colors cursor-pointer">
              Contact
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link href="/signin" className="text-sky-600 hover:text-sky-700 font-medium cursor-pointer whitespace-nowrap">
              Sign In
            </Link>
            <Link href="/register" className="bg-sky-500 text-white px-6 py-2 rounded-full hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap">
              Register
            </Link>
          </div>

          <button 
            className="md:hidden w-6 h-6 flex items-center justify-center cursor-pointer"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-sky-100">
            <div className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-700 hover:text-sky-600 cursor-pointer">Home</Link>
              <Link href="/doctors" className="text-gray-700 hover:text-sky-600 cursor-pointer">Doctors</Link>
              <Link href="/services" className="text-gray-700 hover:text-sky-600 cursor-pointer">Services</Link>
              <Link href="/about" className="text-gray-700 hover:text-sky-600 cursor-pointer">About</Link>
              <Link href="/contact" className="text-gray-700 hover:text-sky-600 cursor-pointer">Contact</Link>
              <div className="flex flex-col space-y-2 pt-4 border-t border-sky-100">
                <Link href="/signin" className="text-sky-600 font-medium cursor-pointer">Sign In</Link>
                <Link href="/register" className="bg-sky-500 text-white px-6 py-2 rounded-full text-center cursor-pointer whitespace-nowrap">
                  Register
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}