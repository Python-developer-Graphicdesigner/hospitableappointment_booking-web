'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

export default function AppointmentPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: '',
    doctor: '',
    appointmentDate: '',
    appointmentTime: '',
    reason: '',
    paymentMethod: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    paypalEmail: ''
  });

  const [showAlert, setShowAlert] = useState({ show: false, type: '', message: '' });
  const [currentStep, setCurrentStep] = useState(1);

  const doctors = [
    { id: 1, name: 'Dr. Sarah Johnson', specialty: 'Cardiologist', times: ['9:00 AM', '11:00 AM', '2:00 PM', '4:00 PM'] },
    { id: 2, name: 'Dr. Michael Chen', specialty: 'Neurologist', times: ['10:00 AM', '1:00 PM', '3:00 PM', '5:00 PM'] },
    { id: 3, name: 'Dr. Emily Rodriguez', specialty: 'Pediatrician', times: ['8:00 AM', '10:00 AM', '1:00 PM', '3:00 PM'] },
    { id: 4, name: 'Dr. Robert Thompson', specialty: 'Orthopedic Surgeon', times: ['9:00 AM', '12:00 PM', '2:00 PM', '4:00 PM'] }
  ];

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateStep = (step: number) => {
    switch (step) {
      case 1:
        return formData.firstName && formData.lastName && formData.email && formData.phone && formData.dateOfBirth && formData.gender;
      case 2:
        return formData.doctor && formData.appointmentDate && formData.appointmentTime && formData.reason;
      case 3:
        if (formData.paymentMethod === 'credit') {
          return formData.cardNumber && formData.expiryDate && formData.cvv;
        } else if (formData.paymentMethod === 'paypal') {
          return formData.paypalEmail;
        }
        return formData.paymentMethod;
      default:
        return false;
    }
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    
    if (!validateStep(3)) {
      setShowAlert({ show: true, type: 'error', message: 'Please fill in all required fields.' });
      return;
    }

    const appointmentData = new URLSearchParams();
    Object.entries(formData).forEach(([key, value]) => {
      appointmentData.append(key, value);
    });

    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: appointmentData
      });

      if (response.ok) {
        setShowAlert({ 
          show: true, 
          type: 'success', 
          message: 'Appointment booked successfully! Confirmation email has been sent.' 
        });
        setFormData({
          firstName: '', lastName: '', email: '', phone: '', dateOfBirth: '', gender: '',
          doctor: '', appointmentDate: '', appointmentTime: '', reason: '',
          paymentMethod: '', cardNumber: '', expiryDate: '', cvv: '', paypalEmail: ''
        });
        setCurrentStep(1);
      } else {
        throw new Error('Booking failed');
      }
    } catch (error) {
      setShowAlert({ 
        show: true, 
        type: 'error', 
        message: 'Failed to book appointment. Please try again.' 
      });
    }
  };

  const selectedDoctor = doctors.find(d => d.name === formData.doctor);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <div className="bg-sky-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">Book Your Appointment</h1>
            <p className="text-xl text-gray-600">Schedule your visit with our expert healthcare professionals</p>
          </div>

          {/* Progress Steps */}
          <div className="max-w-4xl mx-auto mb-12">
            <div className="flex items-center justify-between">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center font-semibold ${
                    currentStep >= step ? 'bg-sky-500 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {step}
                  </div>
                  <div className="ml-4 hidden sm:block">
                    <p className={`font-medium ${currentStep >= step ? 'text-sky-600' : 'text-gray-400'}`}>
                      {step === 1 ? 'Personal Info' : step === 2 ? 'Appointment Details' : 'Payment'}
                    </p>
                  </div>
                  {step < 3 && <div className={`flex-1 h-1 mx-8 ${currentStep > step ? 'bg-sky-500' : 'bg-gray-200'}`}></div>}
                </div>
              ))}
            </div>
          </div>

          <div className="max-w-4xl mx-auto">
            <form id="appointment-form" onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-lg p-8">
              
              {/* Step 1: Personal Information */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-800 mb-6">Personal Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">First Name *</label>
                      <input 
                        type="text" 
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Last Name *</label>
                      <input 
                        type="text" 
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Email Address *</label>
                      <input 
                        type="email" 
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Phone Number *</label>
                      <input 
                        type="tel" 
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Date of Birth *</label>
                      <input 
                        type="date" 
                        name="dateOfBirth"
                        value={formData.dateOfBirth}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Gender *</label>
                      <div className="relative">
                        <select 
                          name="gender"
                          value={formData.gender}
                          onChange={handleInputChange}
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 pr-8"
                          required
                        >
                          <option value="">Select Gender</option>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Appointment Details */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-800 mb-6">Appointment Details</h2>
                  
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Select Doctor *</label>
                    <div className="relative">
                      <select 
                        name="doctor"
                        value={formData.doctor}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 pr-8"
                        required
                      >
                        <option value="">Choose a doctor</option>
                        {doctors.map((doctor) => (
                          <option key={doctor.id} value={doctor.name}>
                            {doctor.name} - {doctor.specialty}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Appointment Date *</label>
                      <input 
                        type="date" 
                        name="appointmentDate"
                        value={formData.appointmentDate}
                        onChange={handleInputChange}
                        min={new Date().toISOString().split('T')[0]}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Appointment Time *</label>
                      <div className="relative">
                        <select 
                          name="appointmentTime"
                          value={formData.appointmentTime}
                          onChange={handleInputChange}
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 pr-8"
                          required
                        >
                          <option value="">Select time</option>
                          {selectedDoctor?.times.map((time) => (
                            <option key={time} value={time}>{time}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Reason for Visit *</label>
                    <textarea 
                      name="reason"
                      value={formData.reason}
                      onChange={handleInputChange}
                      maxLength={500}
                      rows={4}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none"
                      placeholder="Please describe your symptoms or reason for the appointment..."
                      required
                    ></textarea>
                    <p className="text-sm text-gray-500 mt-1">{formData.reason.length}/500 characters</p>
                  </div>
                </div>
              )}

              {/* Step 3: Payment Information */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-800 mb-6">Payment Information</h2>
                  
                  <div>
                    <label className="block text-gray-700 font-medium mb-4">Payment Method *</label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[
                        { value: 'credit', label: 'Credit Card', icon: 'ri-bank-card-line' },
                        { value: 'paypal', label: 'PayPal', icon: 'ri-paypal-line' },
                        { value: 'transfer', label: 'Bank Transfer', icon: 'ri-bank-line' }
                      ].map((method) => (
                        <label key={method.value} className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-sky-50">
                          <input 
                            type="radio" 
                            name="paymentMethod"
                            value={method.value}
                            checked={formData.paymentMethod === method.value}
                            onChange={handleInputChange}
                            className="sr-only"
                          />
                          <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                            formData.paymentMethod === method.value ? 'border-sky-500 bg-sky-500' : 'border-gray-300'
                          }`}>
                            {formData.paymentMethod === method.value && (
                              <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                            )}
                          </div>
                          <div className="w-6 h-6 flex items-center justify-center mr-3">
                            <i className={`${method.icon} text-xl text-sky-500`}></i>
                          </div>
                          <span className="font-medium">{method.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {formData.paymentMethod === 'credit' && (
                    <div className="space-y-4 p-6 bg-sky-50 rounded-lg">
                      <div>
                        <label className="block text-gray-700 font-medium mb-2">Card Number *</label>
                        <input 
                          type="text" 
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          placeholder="1234 5678 9012 3456"
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">Expiry Date *</label>
                          <input 
                            type="text" 
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            placeholder="MM/YY"
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">CVV *</label>
                          <input 
                            type="text" 
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            placeholder="123"
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                            required
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {formData.paymentMethod === 'paypal' && (
                    <div className="p-6 bg-sky-50 rounded-lg">
                      <label className="block text-gray-700 font-medium mb-2">PayPal Email *</label>
                      <input 
                        type="email" 
                        name="paypalEmail"
                        value={formData.paypalEmail}
                        onChange={handleInputChange}
                        placeholder="your@email.com"
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required
                      />
                    </div>
                  )}

                  {formData.paymentMethod === 'transfer' && (
                    <div className="p-6 bg-sky-50 rounded-lg">
                      <h3 className="font-semibold text-gray-800 mb-3">Bank Transfer Details</h3>
                      <div className="space-y-2 text-sm text-gray-600">
                        <p><strong>Bank Name:</strong> MediCare Hospital Bank</p>
                        <p><strong>Account Number:</strong> 1234567890</p>
                        <p><strong>Routing Number:</strong> 987654321</p>
                        <p><strong>Reference:</strong> Please include your name and appointment date</p>
                      </div>
                    </div>
                  )}

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-800 mb-4">Appointment Summary</h3>
                    <div className="space-y-2 text-sm">
                      <p><strong>Patient:</strong> {formData.firstName} {formData.lastName}</p>
                      <p><strong>Doctor:</strong> {formData.doctor}</p>
                      <p><strong>Date:</strong> {formData.appointmentDate}</p>
                      <p><strong>Time:</strong> {formData.appointmentTime}</p>
                      <p><strong>Consultation Fee:</strong> $150.00</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between pt-8 border-t border-gray-200">
                {currentStep > 1 && (
                  <button 
                    type="button"
                    onClick={() => setCurrentStep(currentStep - 1)}
                    className="bg-gray-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Previous
                  </button>
                )}
                
                {currentStep < 3 ? (
                  <button 
                    type="button"
                    onClick={() => {
                      if (validateStep(currentStep)) {
                        setCurrentStep(currentStep + 1);
                      } else {
                        setShowAlert({ show: true, type: 'error', message: 'Please fill in all required fields.' });
                      }
                    }}
                    className="bg-sky-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer ml-auto whitespace-nowrap"
                  >
                    Next
                  </button>
                ) : (
                  <button 
                    type="submit"
                    className="bg-sky-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer ml-auto whitespace-nowrap"
                  >
                    Book Appointment
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Alert Modal */}
      {showAlert.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md mx-4">
            <div className="flex items-center mb-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                showAlert.type === 'success' ? 'bg-green-100' : 'bg-red-100'
              }`}>
                <i className={`${showAlert.type === 'success' ? 'ri-check-line text-green-600' : 'ri-error-warning-line text-red-600'} text-2xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800">
                {showAlert.type === 'success' ? 'Success!' : 'Error'}
              </h3>
            </div>
            <p className="text-gray-600 mb-6">{showAlert.message}</p>
            <button 
              onClick={() => setShowAlert({ show: false, type: '', message: '' })}
              className="w-full bg-sky-500 text-white py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap"
            >
              Close
            </button>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}