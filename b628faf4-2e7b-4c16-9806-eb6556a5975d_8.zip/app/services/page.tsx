
'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function ServicesPage() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const services = [
    {
      icon: 'ri-heart-pulse-line',
      title: 'Cardiology',
      description: 'Comprehensive heart and cardiovascular care including diagnosis, treatment, and prevention of heart diseases.',
      features: ['ECG Testing', 'Echocardiography', 'Cardiac Catheterization', 'Heart Surgery'],
      image: 'https://readdy.ai/api/search-image?query=Modern%20cardiology%20department%20with%20heart%20monitoring%20equipment%20and%20medical%20devices%20in%20clean%20hospital%20setting%2C%20professional%20healthcare%20environment%20with%20soft%20lighting%20and%20medical%20technology&width=800&height=500&seq=card1&orientation=landscape'
    },
    {
      icon: 'ri-brain-line',
      title: 'Neurology',
      description: 'Advanced neurological care for brain, spinal cord, and nervous system disorders with cutting-edge technology.',
      features: ['MRI Scans', 'EEG Testing', 'Stroke Treatment', 'Epilepsy Care'],
      image: 'https://readdy.ai/api/search-image?query=Advanced%20neurology%20department%20with%20brain%20imaging%20equipment%20and%20neurological%20diagnostic%20tools%20in%20modern%20hospital%2C%20clean%20medical%20environment%20with%20professional%20lighting&width=800&height=500&seq=neuro1&orientation=landscape'
    },
    {
      icon: 'ri-parent-line',
      title: 'Pediatrics',
      description: 'Specialized healthcare services for infants, children, and adolescents in a child-friendly environment.',
      features: ['Well-Child Visits', 'Vaccinations', 'Growth Monitoring', 'Pediatric Surgery'],
      image: 'https://readdy.ai/api/search-image?query=Colorful%20pediatric%20department%20with%20child-friendly%20medical%20equipment%20and%20toys%20in%20bright%20hospital%20setting%2C%20welcoming%20healthcare%20environment%20for%20children%20with%20soft%20lighting&width=800&height=500&seq=pedi1&orientation=landscape'
    },
    {
      icon: 'ri-surgical-mask-line',
      title: 'Surgery',
      description: 'State-of-the-art surgical procedures with minimally invasive techniques and advanced operating theaters.',
      features: ['Laparoscopic Surgery', 'Robotic Surgery', 'Emergency Surgery', 'Day Surgery'],
      image: 'https://readdy.ai/api/search-image?query=Modern%20operating%20theater%20with%20advanced%20surgical%20equipment%20and%20sterile%20environment%2C%20professional%20medical%20facility%20with%20bright%20surgical%20lights%20and%20clean%20surfaces&width=800&height=500&seq=surg1&orientation=landscape'
    },
    {
      icon: 'ri-microscope-line',
      title: 'Laboratory Services',
      description: 'Comprehensive diagnostic testing and pathology services with rapid results and accurate analysis.',
      features: ['Blood Tests', 'Urine Analysis', 'Biopsy Services', 'Genetic Testing'],
      image: 'https://readdy.ai/api/search-image?query=Modern%20medical%20laboratory%20with%20diagnostic%20equipment%20and%20testing%20machines%20in%20clean%20hospital%20setting%2C%20professional%20healthcare%20lab%20environment%20with%20bright%20lighting&width=800&height=500&seq=lab1&orientation=landscape'
    },
    {
      icon: 'ri-image-line',
      title: 'Radiology',
      description: 'Advanced medical imaging services including X-rays, CT scans, MRI, and ultrasound diagnostics.',
      features: ['X-Ray Imaging', 'CT Scans', 'MRI Services', 'Ultrasound'],
      image: 'https://readdy.ai/api/search-image?query=Advanced%20radiology%20department%20with%20MRI%20machine%20and%20medical%20imaging%20equipment%20in%20modern%20hospital%2C%20clean%20medical%20environment%20with%20professional%20lighting&width=800&height=500&seq=radio1&orientation=landscape'
    }
  ];

  // Auto-play functionality
  useEffect(() => {
    if (isAutoPlaying) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % services.length);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isAutoPlaying, services.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % services.length);
    setIsAutoPlaying(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + services.length) % services.length);
    setIsAutoPlaying(false);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 to-white">
      <Header />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-sky-400 to-sky-600 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Our Medical Services</h1>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Comprehensive healthcare services delivered with cutting-edge technology and compassionate care
            </p>
          </div>
        </div>
      </div>

      {/* Services Slider */}
      <div className="py-20">
        <div className="container mx-auto px-4">
          <div className="relative bg-white rounded-3xl shadow-2xl overflow-hidden">
            {/* Slider Container */}
            <div className="relative h-[600px] overflow-hidden">
              {services.map((service, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-all duration-700 ease-in-out ${
                    index === currentSlide 
                      ? 'opacity-100 translate-x-0' 
                      : index < currentSlide 
                        ? 'opacity-0 -translate-x-full' 
                        : 'opacity-0 translate-x-full'
                  }`}
                >
                  <div className="grid grid-cols-1 lg:grid-cols-2 h-full">
                    {/* Content Side */}
                    <div className="flex flex-col justify-center p-12 bg-gradient-to-br from-sky-50 to-white">
                      <div className="w-20 h-20 bg-gradient-to-r from-sky-400 to-sky-600 rounded-full flex items-center justify-center mb-6 shadow-lg">
                        <i className={`${service.icon} text-white text-3xl`}></i>
                      </div>
                      <h2 className="text-4xl font-bold text-gray-800 mb-4">{service.title}</h2>
                      <p className="text-lg text-gray-600 mb-8 leading-relaxed">{service.description}</p>
                      
                      <div className="mb-8">
                        <h3 className="text-xl font-semibold text-sky-700 mb-4">Our Services Include:</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {service.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center bg-white rounded-lg p-3 shadow-sm">
                              <div className="w-3 h-3 bg-gradient-to-r from-sky-400 to-sky-600 rounded-full mr-3"></div>
                              <span className="text-gray-700 font-medium">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <Link href="/appointment" className="bg-gradient-to-r from-sky-500 to-sky-600 text-white px-8 py-4 rounded-full font-semibold hover:from-sky-600 hover:to-sky-700 transition-all duration-300 cursor-pointer inline-block whitespace-nowrap shadow-lg hover:shadow-xl transform hover:scale-105">
                        Book Appointment Now
                      </Link>
                    </div>
                    
                    {/* Image Side */}
                    <div className="relative overflow-hidden">
                      <img 
                        src={service.image} 
                        alt={service.title}
                        className="w-full h-full object-cover object-top"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-sky-900/20 to-transparent"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation Arrows */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer z-10 group"
            >
              <i className="ri-arrow-left-line text-sky-600 text-xl group-hover:scale-110 transition-transform"></i>
            </button>
            
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer z-10 group"
            >
              <i className="ri-arrow-right-line text-sky-600 text-xl group-hover:scale-110 transition-transform"></i>
            </button>

            {/* Slide Indicators */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-3 z-10">
              {services.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 cursor-pointer ${
                    index === currentSlide 
                      ? 'bg-sky-500 w-8' 
                      : 'bg-white/60 hover:bg-white/80'
                  }`}
                />
              ))}
            </div>

            {/* Auto-play Control */}
            <button
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className="absolute top-4 right-4 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 cursor-pointer z-10"
            >
              <i className={`${isAutoPlaying ? 'ri-pause-line' : 'ri-play-line'} text-sky-600 text-lg`}></i>
            </button>
          </div>

          {/* Service Counter */}
          <div className="text-center mt-8">
            <div className="inline-flex items-center bg-white rounded-full px-6 py-3 shadow-lg">
              <span className="text-sky-600 font-semibold">
                {currentSlide + 1} of {services.length} Services
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Section */}
      <div className="bg-gradient-to-b from-white to-sky-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Why Choose Our Services?</h2>
            <p className="text-xl text-gray-600">Excellence in healthcare with patient-centered approach</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: 'ri-award-line', title: 'Expert Care', desc: 'Board-certified specialists with years of experience' },
              { icon: 'ri-time-line', title: '24/7 Emergency', desc: 'Round-the-clock emergency services available' },
              { icon: 'ri-shield-check-line', title: 'Advanced Technology', desc: 'State-of-the-art medical equipment and facilities' }
            ].map((feature, index) => (
              <div key={index} className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="w-16 h-16 bg-gradient-to-r from-sky-400 to-sky-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <i className={`${feature.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
