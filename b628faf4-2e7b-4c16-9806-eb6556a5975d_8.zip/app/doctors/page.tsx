
'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function DoctorsPage() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const doctors = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      specialty: 'Cardiologist',
      experience: '15 years',
      rating: 4.9,
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20cardiologist%20doctor%20in%20white%20coat%20smiling%20warmly%20in%20modern%20hospital%20setting%20with%20soft%20lighting%20and%20clean%20medical%20background%2C%20confident%20and%20approachable%20healthcare%20professional%20portrait&width=600&height=400&seq=doc1&orientation=landscape',
      availability: ['9:00 AM', '11:00 AM', '2:00 PM', '4:00 PM'],
      education: 'Harvard Medical School',
      description: 'Specializes in heart disease prevention and treatment with over 15 years of experience.'
    },
    {
      id: 2,
      name: 'Dr. Michael Chen',
      specialty: 'Neurologist',
      experience: '12 years',
      rating: 4.8,
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20neurologist%20doctor%20in%20white%20medical%20coat%20with%20stethoscope%20in%20modern%20hospital%20environment%2C%20clean%20background%20with%20soft%20medical%20lighting%2C%20trustworthy%20healthcare%20specialist%20portrait&width=600&height=400&seq=doc2&orientation=landscape',
      availability: ['10:00 AM', '1:00 PM', '3:00 PM', '5:00 PM'],
      education: 'Johns Hopkins University',
      description: 'Expert in neurological disorders and brain health with extensive research background.'
    },
    {
      id: 3,
      name: 'Dr. Emily Rodriguez',
      specialty: 'Pediatrician',
      experience: '10 years',
      rating: 4.9,
      image: 'https://readdy.ai/api/search-image?query=Friendly%20female%20pediatrician%20doctor%20in%20white%20coat%20smiling%20with%20child-friendly%20demeanor%20in%20bright%20modern%20medical%20office%2C%20soft%20lighting%20and%20clean%20healthcare%20background%2C%20caring%20healthcare%20professional&width=600&height=400&seq=doc3&orientation=landscape',
      availability: ['8:00 AM', '10:00 AM', '1:00 PM', '3:00 PM'],
      education: 'Stanford Medical School',
      description: 'Dedicated to providing comprehensive healthcare for children from infancy to adolescence.'
    },
    {
      id: 4,
      name: 'Dr. Robert Thompson',
      specialty: 'Orthopedic Surgeon',
      experience: '18 years',
      rating: 4.7,
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20orthopedic%20surgeon%20in%20white%20medical%20coat%20with%20confident%20expression%20in%20modern%20hospital%20setting%2C%20clean%20medical%20background%20with%20soft%20professional%20lighting%2C%20experienced%20healthcare%20specialist&width=600&height=400&seq=doc4&orientation=landscape',
      availability: ['9:00 AM', '12:00 PM', '2:00 PM', '4:00 PM'],
      education: 'Yale School of Medicine',
      description: 'Specializes in joint replacement and sports medicine with cutting-edge surgical techniques.'
    },
    {
      id: 5,
      name: 'Dr. Lisa Park',
      specialty: 'Dermatologist',
      experience: '8 years',
      rating: 4.8,
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20dermatologist%20in%20white%20coat%20with%20friendly%20expression%20in%20modern%20medical%20office%2C%20clean%20bright%20background%20with%20soft%20lighting%2C%20skincare%20specialist%20portrait&width=600&height=400&seq=doc5&orientation=landscape',
      availability: ['9:00 AM', '11:00 AM', '2:00 PM', '5:00 PM'],
      education: 'UCLA Medical School',
      description: 'Expert in skin health, cosmetic procedures, and dermatological treatments.'
    },
    {
      id: 6,
      name: 'Dr. James Wilson',
      specialty: 'Gastroenterologist',
      experience: '14 years',
      rating: 4.6,
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20gastroenterologist%20doctor%20in%20white%20medical%20coat%20with%20warm%20smile%20in%20hospital%20setting%2C%20clean%20medical%20background%20with%20professional%20lighting%2C%20digestive%20health%20specialist&width=600&height=400&seq=doc6&orientation=landscape',
      availability: ['10:00 AM', '1:00 PM', '3:00 PM', '4:00 PM'],
      education: 'Mayo Clinic Medical School',
      description: 'Specializes in digestive system disorders and endoscopic procedures.'
    }
  ];

  // 自动播放功能
  useEffect(() => {
    if (isAutoPlaying) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % doctors.length);
      }, 4000);
      return () => clearInterval(interval);
    }
  }, [isAutoPlaying, doctors.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % doctors.length);
    setIsAutoPlaying(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + doctors.length) % doctors.length);
    setIsAutoPlaying(false);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-sky-100">
      <Header />
      
      <div className="bg-gradient-to-r from-sky-400 to-sky-600 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Our Expert Doctors</h1>
            <p className="text-xl text-sky-100 max-w-3xl mx-auto">
              Meet our team of highly qualified healthcare professionals dedicated to providing you with the best medical care
            </p>
          </div>

          {/* 医生滑块 */}
          <div className="relative bg-white rounded-3xl shadow-2xl overflow-hidden mb-12">
            <div className="relative h-[500px] overflow-hidden">
              {doctors.map((doctor, index) => (
                <div
                  key={doctor.id}
                  className={`absolute inset-0 transition-all duration-700 ease-in-out ${
                    index === currentSlide 
                      ? 'opacity-100 translate-x-0' 
                      : index < currentSlide 
                        ? 'opacity-0 -translate-x-full' 
                        : 'opacity-0 translate-x-full'
                  }`}
                >
                  <div className="grid grid-cols-1 lg:grid-cols-2 h-full">
                    {/* 医生信息 */}
                    <div className="flex flex-col justify-center p-12 bg-gradient-to-br from-sky-50 to-white">
                      <div className="mb-6">
                        <h2 className="text-4xl font-bold text-gray-800 mb-2">{doctor.name}</h2>
                        <div className="flex items-center mb-3">
                          <span className="bg-gradient-to-r from-sky-500 to-sky-600 text-white px-4 py-2 rounded-full text-lg font-semibold mr-4">
                            {doctor.specialty}
                          </span>
                          <span className="bg-sky-100 text-sky-700 px-3 py-1 rounded-full text-sm font-medium">
                            {doctor.experience}
                          </span>
                        </div>
                        <p className="text-sky-600 font-medium mb-4">{doctor.education}</p>
                      </div>

                      <div className="flex items-center mb-6 bg-sky-50 p-4 rounded-xl">
                        <div className="flex text-sky-400 mr-3">
                          {[...Array(5)].map((_, i) => (
                            <i key={i} className={`ri-star-${i < Math.floor(doctor.rating) ? 'fill' : 'line'} text-lg`}></i>
                          ))}
                        </div>
                        <span className="text-sky-600 text-lg font-bold">{doctor.rating}</span>
                        <span className="text-gray-500 ml-2">Patient Rating</span>
                      </div>

                      <p className="text-gray-600 text-lg mb-8 leading-relaxed bg-white p-4 rounded-xl shadow-sm">
                        {doctor.description}
                      </p>

                      <div className="mb-8">
                        <h3 className="text-lg font-semibold text-sky-700 mb-3">Available Today:</h3>
                        <div className="flex flex-wrap gap-2">
                          {doctor.availability.map((time, timeIndex) => (
                            <span key={timeIndex} className="bg-sky-500 text-white px-4 py-2 rounded-full text-sm font-medium shadow-md">
                              {time}
                            </span>
                          ))}
                        </div>
                      </div>

                      <Link href="/appointment" className="bg-gradient-to-r from-sky-500 to-sky-600 text-white px-8 py-4 rounded-full font-semibold hover:from-sky-600 hover:to-sky-700 transition-all duration-300 cursor-pointer inline-block whitespace-nowrap shadow-lg hover:shadow-xl transform hover:scale-105">
                        Book Appointment Now
                      </Link>
                    </div>
                    
                    {/* 医生图片 */}
                    <div className="relative overflow-hidden">
                      <img 
                        src={doctor.image} 
                        alt={doctor.name}
                        className="w-full h-full object-cover object-top"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-sky-900/20 to-transparent"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* 导航箭头 */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer z-10 group"
            >
              <i className="ri-arrow-left-line text-sky-600 text-xl group-hover:scale-110 transition-transform"></i>
            </button>
            
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer z-10 group"
            >
              <i className="ri-arrow-right-line text-sky-600 text-xl group-hover:scale-110 transition-transform"></i>
            </button>

            {/* 滑块指示器 */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-3 z-10">
              {doctors.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 cursor-pointer ${
                    index === currentSlide 
                      ? 'bg-sky-500 w-8' 
                      : 'bg-white/60 hover:bg-white/80'
                  }`}
                />
              ))}
            </div>

            {/* 自动播放控制 */}
            <button
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className="absolute top-4 right-4 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 cursor-pointer z-10"
            >
              <i className={`${isAutoPlaying ? 'ri-pause-line' : 'ri-play-line'} text-sky-600 text-lg`}></i>
            </button>
          </div>

          {/* 医生计数器 */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center bg-white rounded-full px-6 py-3 shadow-lg">
              <span className="text-sky-600 font-semibold">
                {currentSlide + 1} of {doctors.length} Doctors
              </span>
            </div>
          </div>

          {/* 所有医生网格视图 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {doctors.map((doctor) => (
              <div key={doctor.id} className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl hover:scale-105 transition-all duration-300 border border-sky-200">
                <div className="aspect-square overflow-hidden relative">
                  <img 
                    src={doctor.image} 
                    alt={doctor.name}
                    className="w-full h-full object-cover object-top"
                  />
                  <div className="absolute top-4 right-4 bg-sky-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {doctor.experience}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-1">{doctor.name}</h3>
                  <p className="text-sky-600 font-medium mb-2 text-lg">{doctor.specialty}</p>
                  <p className="text-sky-500 text-sm mb-3 font-medium">{doctor.education}</p>
                  
                  <div className="flex items-center mb-4 bg-sky-50 p-2 rounded-lg">
                    <div className="flex text-sky-400">
                      {[...Array(5)].map((_, i) => (
                        <i key={i} className={`ri-star-${i < Math.floor(doctor.rating) ? 'fill' : 'line'} text-sm`}></i>
                      ))}
                    </div>
                    <span className="text-sky-600 text-sm ml-2 font-semibold">{doctor.rating}</span>
                  </div>

                  <p className="text-gray-600 text-sm mb-4 bg-sky-50/50 p-3 rounded-lg">{doctor.description}</p>

                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-sky-700 mb-2">Available Times:</h4>
                    <div className="flex flex-wrap gap-1">
                      {doctor.availability.slice(0, 3).map((time, index) => (
                        <span key={index} className="bg-sky-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                          {time}
                        </span>
                      ))}
                      {doctor.availability.length > 3 && (
                        <span className="text-sky-600 text-xs font-medium bg-sky-100 px-2 py-1 rounded-full">+{doctor.availability.length - 3} more</span>
                      )}
                    </div>
                  </div>
                  
                  <Link href="/appointment" className="w-full bg-gradient-to-r from-sky-500 to-sky-600 text-white py-3 rounded-full text-center hover:from-sky-600 hover:to-sky-700 transition-all duration-300 cursor-pointer block whitespace-nowrap font-semibold shadow-lg hover:shadow-xl">
                    Book Appointment
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
